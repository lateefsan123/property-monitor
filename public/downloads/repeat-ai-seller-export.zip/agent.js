(() => {
  // src/features/seller-signal/constants.js
  var MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1e3;

  // extensions/table-export/src/records.js
  var token = (value) => String(value ?? "").toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");
  var text = (value) => String(value ?? "").replace(/\u00a0/g, " ").trim();
  var RowCollector = class {
    columns = /* @__PURE__ */ new Map();
    rows = /* @__PURE__ */ new Map();
    conflicts = /* @__PURE__ */ new Set();
    add(snapshot2, page) {
      for (const c of snapshot2.columns) {
        const previous = this.columns.get(c.id);
        if (previous && token(previous.label) !== token(c.label)) this.conflicts.add("Column headings changed during collection. Restart with a stable sheet.");
        this.columns.set(c.id, c);
      }
      for (const row of snapshot2.rows) {
        const key = `${page}:${row.id}`;
        const previous = this.rows.get(key) || {};
        for (const [col, value] of Object.entries(row.cells)) {
          if (Object.hasOwn(previous, col) && previous[col] !== value) this.conflicts.add("Rows changed or reused their identifiers while scrolling. This capture cannot be exported safely.");
          previous[col] = value;
        }
        this.rows.set(key, previous);
      }
    }
    result(expectedColumns) {
      const columns = [...this.columns.values()].sort((a, b) => a.order - b.order);
      const rows = [...this.rows.values()];
      const missingCells = rows.filter((row) => columns.some((c) => !Object.hasOwn(row, c.id))).length;
      const issues = [...this.conflicts];
      if (missingCells) issues.push(`${missingCells} rows have columns that were never captured. Try a longer wait or a non-virtual table view.`);
      if (expectedColumns && columns.length !== expectedColumns) issues.push(`Captured ${columns.length} of ${expectedColumns} expected columns.`);
      return { columns, rows, issues };
    }
  };

  // extensions/table-export/src/dom.js
  var rootSelector = 'table,[role="grid"],[role="table"],[role="treegrid"]';
  function visible(el) {
    return !!el?.getClientRects().length && getComputedStyle(el).visibility !== "hidden" && !el.closest('[hidden],[aria-hidden="true"]');
  }
  function cellText(el) {
    const copy = el.cloneNode(true);
    const originalChildren = [...el.querySelectorAll("*")], clonedChildren = [...copy.querySelectorAll("*")];
    originalChildren.forEach((child, i) => {
      if (!visible(child)) clonedChildren[i].remove();
    });
    copy.querySelectorAll('input,select,button,svg,script,style,[aria-hidden="true"],[hidden]').forEach((n) => n.remove());
    return text(el.querySelector('input,select,button,svg,[aria-hidden="true"],[hidden]') ? copy.textContent : el.innerText);
  }
  function cells(row) {
    return [...row.querySelectorAll('th,td,[role="columnheader"],[role="gridcell"],[role="cell"],[role="rowheader"]')].filter((c) => c.closest('tr,[role="row"]') === row && visible(c));
  }
  function columnId(cell, index) {
    for (const attr of ["aria-colindex", "data-colindex", "data-x", "col-id"]) {
      if (cell.hasAttribute(attr)) return `${attr}:${cell.getAttribute(attr)}`;
    }
    return `position:${cell.cellIndex >= 0 ? cell.cellIndex : index}`;
  }
  function rowsOf(root) {
    return [...root.querySelectorAll('tr,[role="row"]')].filter((r) => r.closest(rootSelector) === root && visible(r));
  }
  function snapshot(root) {
    const allRows = rowsOf(root);
    const headingRows = allRows.filter((r, i) => r.closest("thead") || r.querySelector('[role="columnheader"]') || i === 0 && r.querySelector('th:not([scope="row"])'));
    const header = headingRows.at(-1) || allRows[0];
    if (!header) throw new Error("This table has no readable headings. Open a sheet with column headings and try again.");
    const headings = cells(header);
    const columns = headings.map((c, i) => ({ id: columnId(c, i), label: cellText(c) || `Column ${i + 1}`, order: Number(c.getAttribute("aria-colindex") ?? c.getAttribute("data-colindex") ?? c.getAttribute("data-x") ?? (c.cellIndex >= 0 ? c.cellIndex : i)) || i }));
    const serial = columns.find((c) => /^(slno|sno|srno|serialno|serialnumber|row|rowno|no)$/.test(token(c.label)) || c.label === "#");
    const dataRows = allRows.filter((r) => !headingRows.includes(r) && r !== header && !r.closest("tfoot"));
    const problems = /* @__PURE__ */ new Set();
    const rows = dataRows.map((row, i) => {
      const rowCells = cells(row);
      if (rowCells.some((c) => (c.colSpan || 1) > 1 || (c.rowSpan || 1) > 1)) problems.add("Merged cells are not supported. Choose a flat table view.");
      const values = Object.fromEntries(rowCells.map((c, index) => [columnId(c, index), cellText(c)]));
      let id;
      for (const attr of ["aria-rowindex", "data-rowindex", "row-index", "data-y", "data-row-id", "data-id"]) {
        if (row.hasAttribute(attr)) {
          id = `${attr}:${row.getAttribute(attr)}`;
          break;
        }
      }
      if (!id && serial && /^\d+$/.test(values[serial.id] || "")) id = `serial:${values[serial.id]}`;
      return { id: id || `position:${i}`, cells: values };
    }).filter((r) => Object.values(r.cells).some(Boolean));
    if (new Set(rows.map((r) => r.id)).size !== rows.length) problems.add("This table repeats row identifiers. Choose a different table view.");
    if (headings.some((c) => (c.colSpan || 1) > 1)) problems.add("Grouped headings are not supported. Choose a flat table view.");
    return { columns, rows, issues: [...problems] };
  }
  function discoverTables(doc = document) {
    return [...doc.querySelectorAll(rootSelector)].filter((root) => visible(root) && !root.closest("[data-repeat-export-ui]") && !root.parentElement?.closest(rootSelector)).flatMap((root) => {
      try {
        const view = snapshot(root);
        return view.columns.length >= 2 ? [{ root, label: `${root.getAttribute("aria-label") || root.querySelector("caption")?.innerText || "Table"} \u2014 ${view.columns.map((c) => c.label).slice(0, 5).join(", ")}`, view }] : [];
      } catch {
        return [];
      }
    });
  }
  function findTableLike(headings, doc = document) {
    const wanted = new Set(headings.map(token).filter(Boolean));
    const need = Math.min(3, wanted.size);
    for (const root of doc.querySelectorAll(rootSelector)) {
      if (!visible(root) || root.closest("[data-repeat-export-ui]") || root.parentElement?.closest(rootSelector)) continue;
      try {
        const labels = snapshot(root).columns.map((c) => token(c.label));
        if (need && labels.filter((label) => wanted.has(label)).length >= need) return root;
      } catch {
      }
    }
    return null;
  }
  function scopeFor(root) {
    const known = root.closest(".dataTables_wrapper,.dt-container,[data-export-container],.ag-root-wrapper");
    if (known) return known;
    let ancestor = root.parentElement;
    for (let level = 0; ancestor && level < 4; level++, ancestor = ancestor.parentElement) {
      const tables = [...ancestor.querySelectorAll(rootSelector)].filter(visible);
      if (tables.length !== 1) break;
      if (ancestor.querySelector('[role="status"],.pagination,[aria-label="Next page"],.dataTables_info,.dt-info')) return ancestor;
    }
    return root.parentElement;
  }
  function pagerScope(root) {
    let scope = root.parentElement || root;
    for (let el = scope.parentElement, level = 0; el && el !== document.body && level < 8; el = el.parentElement, level++) {
      if ([...el.querySelectorAll(rootSelector)].filter(visible).length !== 1) break;
      scope = el;
    }
    return scope;
  }
  var number = (value) => Number(value.replaceAll(",", ""));
  function scopeLines(root) {
    const lines = [];
    const walker = document.createTreeWalker(pagerScope(root), NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => root.contains(node) || !node.parentElement || !visible(node.parentElement) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const line = text(node.textContent);
      if (line) lines.push(line);
    }
    return lines;
  }
  var PAGE_OF = /^(\d+)\s*(?:\/|of)\s*(\d+)$/i;
  function expectedRows(root) {
    const scope = scopeFor(root);
    const info = scope?.querySelector('.dataTables_info,.dt-info,[role="status"],[data-row-summary]')?.textContent || "";
    const match = info.match(/showing\s+([\d,]+)\s+(?:to|[-–])\s+[\d,]+\s+of\s+([\d,]+)\s+(?:entries|rows|records|results)/i);
    if (match) return { count: Number(match[2].replaceAll(",", "")), startsAt: Number(match[1].replaceAll(",", "")), source: "page counter" };
    const lines = scopeLines(root);
    const page = lines.map((line) => line.match(PAGE_OF)).find(Boolean);
    for (const line of lines) {
      const total = line.match(/^([\d,]+)\s+(?:results|records|contacts|leads|entries|rows|items)$/i) || line.match(/\bof\s+([\d,]+)\s*(?:results|records|contacts|leads|entries|rows|items)?$/i);
      if (total && !PAGE_OF.test(line)) return { count: number(total[1]), startsAt: page && Number(page[1]) > 1 ? 2 : 1, source: "page counter" };
    }
    const count = Number(root.getAttribute("aria-rowcount"));
    if (count > 0) {
      const headers = rowsOf(root).filter((r, i) => r.closest("thead") || r.querySelector('[role="columnheader"]') || i === 0 && r.querySelector('th:not([scope="row"])')).length;
      return { count: Math.max(0, count - headers), startsAt: 1, source: "table row count" };
    }
    return { count: null, startsAt: 1, source: "not published by this page" };
  }
  function scrollContainers(root) {
    const candidates = [root, ...root.querySelectorAll("*")];
    for (let el = root.parentElement; el; el = el.parentElement) candidates.push(el);
    const scrolling = document.scrollingElement;
    if (scrolling && !candidates.includes(scrolling)) candidates.push(scrolling);
    const isScrollable = (el, axis) => {
      if (!visible(el)) return false;
      const style = getComputedStyle(el);
      return (el === scrolling || /(auto|scroll)/.test(axis === "x" ? style.overflowX : style.overflowY)) && (axis === "x" ? el.scrollWidth > el.clientWidth + 2 : el.scrollHeight > el.clientHeight + 2);
    };
    return { x: candidates.find((el) => isScrollable(el, "x")), y: candidates.find((el) => isScrollable(el, "y")) };
  }
  var NEXT_LABEL = /^(next(?: page)?|go to next page|›|»|>)$/;
  var NEXT_HINT = /(^|[^a-z])(next|chevron-?right|arrow-?right|caret-?right|angle-?right|keyboard-?arrow-?right|navigate-?next|forward)([^a-z]|$)/i;
  var hints = (el) => [el, ...el.querySelectorAll("*")].slice(0, 12).map((n) => [n.getAttribute("aria-label"), n.getAttribute("title"), n.getAttribute("data-testid"), n.getAttribute("data-icon"), n.getAttribute("class"), n.getAttribute("name")].filter(Boolean).join(" ")).join(" ");
  function isNext(el) {
    const label = text(el.getAttribute("aria-label") || el.getAttribute("title") || el.innerText).toLowerCase();
    if (NEXT_LABEL.test(label) || el.matches(".paginate_button.next,.dt-paging-button.next")) return true;
    return !text(el.innerText) && NEXT_HINT.test(hints(el)) && !/prev|left|back/i.test(label);
  }
  function isDisabled(el) {
    return el.disabled || el.getAttribute("aria-disabled") === "true" || el.classList.contains("disabled") || !!el.closest('.disabled,[aria-disabled="true"]') || getComputedStyle(el).pointerEvents === "none";
  }
  function afterPageBox(controls, scope) {
    const box = [...scope.querySelectorAll("*")].find((el) => visible(el) && !el.children.length && PAGE_OF.test(text(el.textContent)));
    if (!box) return null;
    return controls.find((el) => !text(el.innerText) && box.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) || null;
  }
  function nextControl(root) {
    const page = scopeLines(root).map((line) => line.match(PAGE_OF)).find(Boolean);
    if (page && Number(page[1]) >= Number(page[2])) return null;
    let el = null;
    for (const scope of [scopeFor(root), pagerScope(root)]) {
      const controls = [...scope?.querySelectorAll('button,a,[role="button"]') || []].filter((c) => visible(c) && !c.closest(rootSelector) && !c.closest("[data-repeat-export-ui]"));
      const matches = controls.filter(isNext);
      el = matches.find((c) => !isDisabled(c)) || matches[0] || afterPageBox(controls, scope);
      if (el) break;
    }
    if (!el || isDisabled(el)) return null;
    const href = el.getAttribute("href");
    if (href && !href.startsWith("#") && !href.startsWith("javascript:")) {
      const target = new URL(href, location.href);
      if (target.origin !== location.origin || target.pathname !== location.pathname) throw new Error("Next opens a new page. Capture this page with automatic pagination off, then add the next page separately.");
    }
    return el;
  }
  function isBusy(root) {
    const scope = scopeFor(root);
    return root.getAttribute("aria-busy") === "true" || !![...scope?.querySelectorAll('[aria-busy="true"],.dataTables_processing,.dt-processing,[role="progressbar"]') || []].find(visible);
  }

  // extensions/table-export/src/scan.js
  var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  var signature = (root) => JSON.stringify(snapshot(root).rows);
  async function scanTable(root, options = {}, progress = () => {
  }, signal = new AbortController().signal) {
    const waitMs = Math.max(100, options.waitMs || 150);
    const idleMs = Math.max(waitMs * 3, options.idleMs || 2500);
    const maxMs = options.maxMs || 20 * 60 * 1e3;
    const maxRows = options.maxRows || 1e5;
    const started = Date.now(), collector = new RowCollector(), issues = /* @__PURE__ */ new Set();
    const initial = expectedRows(root);
    const manualExpected = options.expectedRows > 0 ? Number(options.expectedRows) : null;
    const publishedExpected = options.paginate === false && initial.source === "page counter" ? null : initial.count;
    const expected = publishedExpected ?? manualExpected;
    if (publishedExpected !== null && manualExpected !== null && publishedExpected !== manualExpected) issues.add(`The entered total (${manualExpected}) differs from the source total (${publishedExpected}). Check the expected row count.`);
    const originalScroll = /* @__PURE__ */ new Map();
    const headings = snapshot(root).columns.map((c) => c.label);
    function relocate() {
      if (root.isConnected) return true;
      const replacement = findTableLike(headings);
      if (replacement) root = replacement;
      return Boolean(replacement);
    }
    let pages = 0, steps = 0, finished = false, error = "", transitioning = false;
    function guard() {
      if (signal.aborted) throw new Error("Collection stopped. These rows are a partial capture; clear it and scan again before exporting.");
      if (!relocate() && !transitioning) throw new Error("The table was replaced or the sheet changed. Clear this capture and scan the current sheet again.");
      if (Date.now() - started > maxMs || steps++ > 3e4) throw new Error("Collection reached its time limit. Narrow the page filter or capture smaller sections.");
      if (collector.rows.size > maxRows) throw new Error("Collection exceeded 100,000 rows. Filter the sheet into smaller sections.");
    }
    async function settled() {
      const deadline = Date.now() + (options.loadTimeoutMs || 3e4);
      let changedAt = Date.now();
      const observer = new MutationObserver(() => {
        changedAt = Date.now();
      });
      observer.observe(root, { subtree: true, childList: true, characterData: true, attributes: true });
      try {
        for (; ; ) {
          await sleep(Math.min(waitMs, 100));
          guard();
          if (isBusy(root)) changedAt = Date.now();
          else if (Date.now() - changedAt >= waitMs) return;
          if (Date.now() > deadline) throw new Error("The table is still loading. Wait for it to finish, then scan again.");
        }
      } finally {
        observer.disconnect();
      }
    }
    async function move(el, axis, value) {
      guard();
      const property = axis === "x" ? "scrollLeft" : "scrollTop";
      if (Math.abs(el[property] - value) < 1) return;
      await new Promise((resolve, reject) => {
        const target = el === document.scrollingElement ? document : el;
        const cleanup = () => {
          clearTimeout(timer);
          target.removeEventListener("scroll", done);
          signal.removeEventListener("abort", abort);
        };
        const done = () => {
          cleanup();
          resolve();
        };
        const abort = () => {
          cleanup();
          reject(new Error("Collection stopped. Clear this partial capture and scan again."));
        };
        const timer = setTimeout(() => {
          cleanup();
          reject(new Error("Scrolling did not render. Keep the source tab visible, then collect again."));
        }, options.loadTimeoutMs || 3e4);
        target.addEventListener("scroll", done, { once: true });
        signal.addEventListener("abort", abort, { once: true });
        el[property] = value;
      });
      await settled();
    }
    function remember(el) {
      if (el && !originalScroll.has(el)) {
        originalScroll.set(el, { top: el.scrollTop, left: el.scrollLeft, anchor: el.style.getPropertyValue("overflow-anchor"), priority: el.style.getPropertyPriority("overflow-anchor"), behavior: el.style.getPropertyValue("scroll-behavior"), behaviorPriority: el.style.getPropertyPriority("scroll-behavior") });
        el.style.setProperty("overflow-anchor", "none", "important");
        el.style.setProperty("scroll-behavior", "auto", "important");
      }
    }
    function collect() {
      guard();
      const view = snapshot(root);
      options.trace?.({ top: scrollContainers(root).y?.scrollTop, left: scrollContainers(root).x?.scrollLeft, first: view.rows[0]?.id, last: view.rows.at(-1)?.id, columns: view.columns.map((c) => c.id) });
      view.issues.forEach((i) => issues.add(i));
      collector.add(view, pages);
      guard();
      progress({ rows: collector.rows.size, pages: pages + 1, expected, elapsedMs: Date.now() - started });
    }
    async function horizontal() {
      const { x } = scrollContainers(root);
      remember(x);
      if (!x) {
        collect();
        return;
      }
      const rightward = x.scrollLeft <= (x.scrollWidth - x.clientWidth) / 2;
      await move(x, "x", rightward ? 0 : x.scrollWidth - x.clientWidth);
      collect();
      for (; ; ) {
        const before = x.scrollLeft;
        const edge = rightward ? x.scrollWidth - x.clientWidth : 0;
        if (Math.abs(before - edge) <= 2) break;
        const step = Math.max(1, Math.floor(x.clientWidth * 0.75));
        await move(x, "x", rightward ? Math.min(edge, before + step) : Math.max(0, before - step));
        collect();
        if (Math.abs(x.scrollLeft - before) < 1) throw new Error("Horizontal scrolling stopped before the last column. Try a standard table view.");
      }
    }
    try {
      await settled();
      if (options.paginate !== false && initial.startsAt > 1) throw new Error("Start on the first page before scanning all pages, or turn off automatic pagination to capture this page only.");
      const pageSignatures = /* @__PURE__ */ new Set();
      for (; ; ) {
        guard();
        const scroll = scrollContainers(root);
        remember(scroll.y);
        if (scroll.y) await move(scroll.y, "y", 0);
        const pageSig = signature(root);
        if (pageSignatures.has(pageSig)) throw new Error("Pagination repeated a page. The capture is incomplete.");
        pageSignatures.add(pageSig);
        let stableSince = Date.now(), previousHeight = -1, previousSize = -1;
        for (; ; ) {
          await horizontal();
          if (expected !== null && collector.rows.size === expected && !collector.result(Number(root.getAttribute("aria-colcount")) || null).issues.length && !isBusy(root)) break;
          const { y } = scrollContainers(root);
          remember(y);
          const height = y?.scrollHeight || 0, size = collector.rows.size;
          if (height !== previousHeight || size !== previousSize) stableSince = Date.now();
          previousHeight = height;
          previousSize = size;
          const bottom = !y || y.scrollTop >= y.scrollHeight - y.clientHeight - 2;
          if (bottom && Date.now() - stableSince >= idleMs && !isBusy(root)) break;
          if (y && !bottom) {
            const before2 = y.scrollTop;
            await move(y, "y", Math.min(y.scrollHeight - y.clientHeight, before2 + Math.max(1, Math.floor(y.clientHeight * 0.7))));
            if (y.scrollTop === before2) throw new Error("Scrolling stopped before the end of the table.");
          } else await settled();
        }
        if (options.paginate === false) break;
        if (expected !== null && collector.rows.size >= expected) break;
        const next = nextControl(root);
        if (!next) break;
        const before = signature(root);
        next.click();
        const deadline = Date.now() + (options.loadTimeoutMs || 3e4);
        transitioning = true;
        do {
          await settled();
          if (Date.now() > deadline) throw new Error("Next did not load a different page. The capture is incomplete.");
        } while (!relocate() || signature(root) === before);
        transitioning = false;
        pages++;
      }
      finished = true;
    } catch (cause) {
      error = cause.message;
    } finally {
      for (const [el, position] of originalScroll) if (el.isConnected) {
        el.scrollTop = position.top;
        el.scrollLeft = position.left;
        position.anchor ? el.style.setProperty("overflow-anchor", position.anchor, position.priority) : el.style.removeProperty("overflow-anchor");
        position.behavior ? el.style.setProperty("scroll-behavior", position.behavior, position.behaviorPriority) : el.style.removeProperty("scroll-behavior");
      }
    }
    const result = collector.result(Number(root.getAttribute("aria-colcount")) || null);
    result.issues.forEach((i) => issues.add(i));
    if (error) issues.add(error);
    if (!result.rows.length) issues.add("No seller rows were captured.");
    const countMatches = expected !== null && expected === result.rows.length;
    if (expected !== null && !countMatches) issues.add(`Captured ${result.rows.length} rows; the expected total is ${expected}. Check filters, pagination and loading before exporting.`);
    return {
      ...result,
      issues: [...issues],
      expected,
      expectedSource: publishedExpected !== null ? initial.source : manualExpected !== null ? "entered by user" : "unknown",
      countMatches,
      finished,
      verified: finished && countMatches && !issues.size,
      pages: pages + 1,
      source: `${location.origin}${location.pathname}`,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }

  // extensions/table-export/src/agent.js
  if (!globalThis.__repeatTableExporter) {
    let tables = [], controller, state = { status: "idle" }, heartbeat = Date.now();
    globalThis.__repeatTableExporter = {
      discover() {
        if (state.status === "running") throw new Error("Stop the current scan before choosing another table.");
        tables = discoverTables();
        return tables.map(({ label, view }, id) => ({ id, label, columns: view.columns, visibleRows: view.rows.length }));
      },
      start(id, options) {
        if (state.status === "running") throw new Error("A scan is already running in this tab.");
        const table = tables[id];
        if (!table) throw new Error("Refresh tables and select the current sheet.");
        controller = new AbortController();
        heartbeat = Date.now();
        state = { status: "running", progress: {} };
        const watchdog = setInterval(() => {
          if (Date.now() - heartbeat > 2e4) controller.abort();
        }, 5e3);
        scanTable(table.root, options, (progress) => {
          state.progress = progress;
        }, controller.signal).then((result) => {
          state = { status: "done", result };
        }).catch(() => {
          state = { status: "error", message: "The page could not be read. Refresh tables and try again." };
        }).finally(() => clearInterval(watchdog));
        return true;
      },
      poll() {
        heartbeat = Date.now();
        return state;
      },
      cancel() {
        controller?.abort();
      },
      clear() {
        if (state.status !== "running") state = { status: "idle" };
      }
    };
  }
})();
